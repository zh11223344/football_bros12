function search_animal() {
    let input = document.getElementById('searchbar').value.toLowerCase();
    let games = document.getElementsByClassName('game-card');
    
    for (let i = 0; i < games.length; i++) {
        let title = games[i].querySelector('.game-title').innerText.toLowerCase();
        if (!title.includes(input)) {
            games[i].style.display = "none";
        } else {
            games[i].style.display = "block";
        }
    }
}